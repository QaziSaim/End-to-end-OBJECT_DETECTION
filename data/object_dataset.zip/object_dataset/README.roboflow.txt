
Microsoft COCO - v2 raw
==============================

This dataset was exported via roboflow.ai on April 18, 2022 at 3:28 AM GMT

It includes 121408 images.
Coco-objects are annotated in YOLOv5 Oriented Object Detection format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


